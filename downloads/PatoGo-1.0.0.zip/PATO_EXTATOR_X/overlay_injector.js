(()=>{const d="overlayState",c="pato-page-overlay-host",l="patoOverlay";function m(){let e=document.getElementById(c);if(e)return e;e=document.createElement("div"),e.id=c,e.style.position="fixed",e.style.inset="0",e.style.zIndex="2147483647";const t=document.documentElement||document.body;return t?t.appendChild(e):document.addEventListener("DOMContentLoaded",()=>document.documentElement.appendChild(e),{once:!0}),e}function w(){const e=m();e.innerHTML="";const t=e.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=`
      #wrap{
        position:fixed; inset:0;
        background:rgba(67, 88, 131, 0.18);  /* fundo do overlay opaco */
        backdrop-filter: blur(2px);
        display:none; align-items:center; justify-content:center;
        pointer-events:auto;
      }
      #wrap.show{ display:flex }

      .card{
        display:flex; flex-direction:column; align-items:center; gap:14px;
        padding:24px 28px; border-radius:16px;
        background:#001129;                 /* azul-marinho do pato */
        border:1px solid rgba(255,255,255,0.06);  /* contorno sutil */
        box-shadow:0 16px 40px rgba(0,0,0,.45);
        font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;
        max-width:92vw
      }

      .img{ width:96px; height:96px; animation:float 1.8s ease-in-out infinite }
      @keyframes float{ 0%{transform:translateY(0)} 50%{transform:translateY(-6px)} 100%{transform:translateY(0)} }

      .t{ color:#e2e8f0; font-size:16px; font-weight:700; text-align:center }
      .s{ color:#94a3b8; font-size:13px; text-align:center }

      .spinner{
        width:64px; height:64px; border-radius:50%;
        border:6px solid rgba(255,255,255,0.12);
        border-top-color:#e2e8f0;
        animation:spin .9s linear infinite
      }
      @keyframes spin{ to{ transform:rotate(360deg) } }
    `;const a=document.createElement("div");a.id="wrap";const r=document.createElement("div");r.className="card";let u="";try{u=chrome?.runtime?.getURL?.("icons/duck-loading.gif")||""}catch{}return r.innerHTML=`
      ${u?`<img class="img" src="${u}" alt="Pato carregando"
             onerror="this.outerHTML='<div class=&quot;spinner&quot;></div>'">`:'<div class="spinner"></div>'}
      <div class="t">Carregando\u2026</div>
      <div class="s">Processando\u2026</div>
    `,a.appendChild(r),t.append(n,a),{host:e,root:t,wrap:a,tEl:r.querySelector(".t"),sEl:r.querySelector(".s")}}let o=null;const y=()=>o&&o.wrap?.isConnected?o:o=w();function s(e="Carregando\u2026",t="Processando\u2026"){const{wrap:n,tEl:a,sEl:r}=y();a&&(a.textContent=e||"Carregando\u2026"),r&&(r.textContent=t||"Processando\u2026"),n.classList.add("show"),document.documentElement.style.overflow="hidden",window.__patoOverlayActive=!0,window.__patoOverlayText=e,window.__patoOverlaySub=t;try{sessionStorage.setItem(l,JSON.stringify({on:!0,text:e,sub:t}))}catch{}}function p(){o?.wrap?.classList?.remove("show"),document.documentElement.style.overflow="",window.__patoOverlayActive=!1;try{sessionStorage.removeItem(l)}catch{}}try{const e=sessionStorage.getItem(l);if(e){const t=JSON.parse(e);t&&t.on&&s(t.text||"Carregando\u2026",t.sub||"Processando\u2026")}}catch{}async function i(){try{const{[d]:e}=await chrome.storage.session.get(d);e?.active?s(e.text,e.sub):p()}catch{}}new MutationObserver(()=>{window.__patoOverlayActive&&(!document.getElementById(c)||!o?.wrap?.isConnected||!o.wrap.classList.contains("show"))&&s(window.__patoOverlayText,window.__patoOverlaySub)}).observe(document.documentElement,{childList:!0,subtree:!0}),setInterval(()=>{window.__patoOverlayActive&&(!document.getElementById(c)||!o?.wrap?.isConnected||!o.wrap.classList.contains("show"))&&s(window.__patoOverlayText,window.__patoOverlaySub)},600);const f=history.pushState,h=history.replaceState;history.pushState=function(...e){const t=f.apply(this,e);return queueMicrotask(i),t},history.replaceState=function(...e){const t=h.apply(this,e);return queueMicrotask(i),t},window.addEventListener("popstate",()=>queueMicrotask(i)),window.addEventListener("pageshow",i),document.addEventListener("visibilitychange",()=>{document.hidden||i()}),chrome.storage.onChanged.addListener((e,t)=>{if(t!=="session"||!e[d])return;const n=e[d].newValue;n?.active?s(n.text,n.sub):p()}),chrome.runtime.onMessage.addListener(e=>{e?.type==="overlay:show"&&s(e.text,e.sub),e?.type==="overlay:hide"&&p()}),i()})();
