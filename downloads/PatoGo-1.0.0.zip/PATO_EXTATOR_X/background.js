const DEFAULT_HUMAN={preSearchCountdownSec:2,backspaces:28,searchKeyDelayMs:[35,80],searchPunctPauseMs:[120,260],searchWordPauseProb:.3,searchWordPauseMs:[200,420],afterSearchWaitMs:[5200,8e3],afterClickWaitMs:[2e3,3600],focusComposerRetries:8,focusComposerRetryMs:[220,360],msgKeyDelayMs:[45,110],msgPunctPauseMs:[130,260],msgWordPauseProb:.35,msgWordPauseMs:[240,520],microBreakEvery:[35,80],microBreakMs:[600,1600],batchDelayMs:[3800,7500]};let HUMAN=JSON.parse(JSON.stringify(DEFAULT_HUMAN));async function loadHumanConfig(){try{const{humanConfig:e}=await chrome.storage.sync.get("humanConfig");e&&typeof e=="object"&&(HUMAN=normalizeHumanConfig(e))}catch(e){console.warn("Erro ao carregar humanConfig:",e),HUMAN=JSON.parse(JSON.stringify(DEFAULT_HUMAN))}}function normalizeHumanConfig(e){const a=e||{},t=JSON.parse(JSON.stringify(DEFAULT_HUMAN)),r=(o,l)=>{const u=Number(o);return Number.isFinite(u)&&u>=0?u:l},n=(o,l)=>{if(!Array.isArray(o)||o.length<2)return l;let u=Number(o[0]),i=Number(o[1]);return!Number.isFinite(u)||!Number.isFinite(i)?l:(u>i&&([u,i]=[i,u]),[u,i])};return t.preSearchCountdownSec=r(a.preSearchCountdownSec,DEFAULT_HUMAN.preSearchCountdownSec),t.backspaces=r(a.backspaces,DEFAULT_HUMAN.backspaces),t.searchWordPauseProb=r(a.searchWordPauseProb,DEFAULT_HUMAN.searchWordPauseProb),t.focusComposerRetries=r(a.focusComposerRetries,DEFAULT_HUMAN.focusComposerRetries),t.msgWordPauseProb=r(a.msgWordPauseProb,DEFAULT_HUMAN.msgWordPauseProb),t.searchKeyDelayMs=n(a.searchKeyDelayMs,DEFAULT_HUMAN.searchKeyDelayMs),t.searchPunctPauseMs=n(a.searchPunctPauseMs,DEFAULT_HUMAN.searchPunctPauseMs),t.searchWordPauseMs=n(a.searchWordPauseMs,DEFAULT_HUMAN.searchWordPauseMs),t.afterSearchWaitMs=n(a.afterSearchWaitMs,DEFAULT_HUMAN.afterSearchWaitMs),t.afterClickWaitMs=n(a.afterClickWaitMs,DEFAULT_HUMAN.afterClickWaitMs),t.focusComposerRetryMs=n(a.focusComposerRetryMs,DEFAULT_HUMAN.focusComposerRetryMs),t.msgKeyDelayMs=n(a.msgKeyDelayMs,DEFAULT_HUMAN.msgKeyDelayMs),t.msgPunctPauseMs=n(a.msgPunctPauseMs,DEFAULT_HUMAN.msgPunctPauseMs),t.msgWordPauseMs=n(a.msgWordPauseMs,DEFAULT_HUMAN.msgWordPauseMs),t.microBreakEvery=n(a.microBreakEvery,DEFAULT_HUMAN.microBreakEvery),t.microBreakMs=n(a.microBreakMs,DEFAULT_HUMAN.microBreakMs),t.batchDelayMs=n(a.batchDelayMs,DEFAULT_HUMAN.batchDelayMs),t}loadHumanConfig().catch(()=>{});const sleep=e=>new Promise(a=>setTimeout(a,e)),randInt=(e,a)=>Math.floor(Math.random()*(a-e+1))+e,pickMs=([e,a])=>randInt(Math.min(e,a),Math.max(e,a)),isPunctOrSpace=e=>/[\s.,;:!?]/.test(e);function safeEmail(e){return String(e||"").trim().toLowerCase()}async function getOrCreateDeviceId(){const e="__pato_device_id__",a=await chrome.storage.local.get([e]);if(a[e])return a[e];const t=crypto&&crypto.randomUUID?crypto.randomUUID():String(Date.now())+"-"+Math.random().toString(16).slice(2);return await chrome.storage.local.set({[e]:t}),t}const SEND_BUNDLE_URL="https://divine-smoke-0c82.lucaspsimoes22.workers.dev/send-bundle";let SEND_BUNDLE_META=null;async function fetchSendBundle({email:e="",peek:a=!0}={}){const t=await getOrCreateDeviceId(),r=new URLSearchParams;e&&r.set("email",safeEmail(e)),r.set("device",t),r.set("device_id",t),r.set("peek",a?"1":"0");const n=`${SEND_BUNDLE_URL}?${r.toString()}`,o=await fetch(n,{cache:"no-cache"}),l=await o.json().catch(()=>({}));return{ok:o.ok,status:o.status,data:l}}function isBlockedMeta(e){return e?e.status===429||e.data?.allowed===!1||e.data?.cooldown?.blocked===!0:!1}function extractUntilEpoch(e){return e?.cooldown?.until_epoch??e?.until_epoch??e?.until??null}function sendGateBlockedToPopup(e){sendToPopup({type:"SEND_GATE",blocked:!0,until_epoch:extractUntilEpoch(e),until_brt:e?.cooldown?.until_brt||e?.until_brt||""})}async function gatePeekOrBlock(e){const a=await fetchSendBundle({email:e,peek:!0});return isBlockedMeta(a)?{blocked:!0,data:a.data||{}}:{blocked:!1,data:a.data||null}}async function gateConsumeOrBlock(e){const a=await fetchSendBundle({email:e,peek:!1});if(isBlockedMeta(a))return{blocked:!0,data:a.data||{}};if(a.ok&&a.data)try{SELECTORS=validateAndExtractSelectors(a.data),SEND_BUNDLE_META=a.data||null,await chrome.storage.local.set({__sel_cache__:a.data})}catch{}return{blocked:!1,data:a.data||null}}function isProFromServerMeta(e){if(!e)return!1;const a=String(e.plan||e.tier||e.subscription||"").toLowerCase().trim();return!!(e.is_pro||e.pro===!0||e.pro_enabled===!0)||a==="pro"||a==="premium"||a==="paid"}function normText(e){return String(e||"").toLowerCase().normalize("NFD").replace(new RegExp("\\p{Diacritic}","gu"),"").replace(/[\u200B-\u200D\uFEFF]/g,"").replace(/[\p{Emoji_Presentation}\p{Extended_Pictographic}]/gu,"").replace(/[^\p{L}\p{N}\s+]/gu,"").replace(/\s+/g," ").trim()}function normPhoneLike(e){return String(e||"").replace(/[^\d]/g,"")}function looksLikePhone(e){return normPhoneLike(e).length>=8}function isMatchTermVsTitle(e,a){const t=normText(e),r=normText(a);if(looksLikePhone(e)||looksLikePhone(a)){const o=normPhoneLike(e),l=normPhoneLike(a);return!o||!l?!1:l.endsWith(o)||l.includes(o)||o.endsWith(l)}if(r===t||r.includes(t)||t.includes(r)&&r.length>=3)return!0;const n=t.split(" ").filter(Boolean);if(n.length>=2){const o=n.slice(0,2).join(" ");if(r.includes(o))return!0}return!1}function personalizeMessage(e,a){const t=String(a?.nome||"").trim(),r=t.split(/\s+/)[0]||t;let n=String(e||"");return n=n.replace(/\{NOME\}/gi,t),n=n.replace(/\{PRIMEIRO_NOME\}/gi,r),n}let currentBatch={isRunning:!1,contacts:[],currentIndex:-1,message:"",messageTemplates:null,sendAfter:!0,batchPort:null,targetTabId:null,email:"",isPro:!1};function sendToPopup(e){if(currentBatch.batchPort)try{currentBatch.batchPort.postMessage(e)}catch{}}const stage=(e,a={})=>sendToPopup({type:"LOG_MESSAGE",level:"stage",stage:e,...a}),fail=(e,a={})=>sendToPopup({type:"LOG_MESSAGE",level:"err",stage:e,...a}),REQUIRED_KEYS=["highlight","row","rowTitle","searchBox","composer","openTitle"];let SELECTORS=null;function _isArrayNonEmpty(e){return Array.isArray(e)&&e.length>0}function validateAndExtractSelectors(e){const a=e?.data&&e.data.selectors?e.data:e;if(!a||typeof a!="object"||!a.selectors||typeof a.selectors!="object")throw new Error("selectors-missing");for(const r of REQUIRED_KEYS)if(!_isArrayNonEmpty(a.selectors[r]))throw new Error("selector-key-missing:"+r);const t={};for(const r of Object.keys(a.selectors))Array.isArray(a.selectors[r])&&(t[r]=a.selectors[r].filter(Boolean));return t}async function loadSelectorsRemoteStrict(e=""){try{const{ok:a,status:t,data:r}=await fetchSendBundle({email:e,peek:!0});if(!a)throw new Error("HTTP "+t);SELECTORS=validateAndExtractSelectors(r),SEND_BUNDLE_META=r||null,await chrome.storage.local.set({__sel_cache__:r}),stage("selectors:loaded",{url:SEND_BUNDLE_URL,version:r?.data?.version||null,updated_at:r?.data?.updated_at||null,plan:r?.plan||r?.tier||null})}catch(a){const t=await chrome.storage.local.get(["__sel_cache__"]);if(t.__sel_cache__){SELECTORS=validateAndExtractSelectors(t.__sel_cache__),SEND_BUNDLE_META=t.__sel_cache__||null,stage("selectors:using-cache",{reason:String(a).slice(0,160)});return}throw SELECTORS=null,SEND_BUNDLE_META=null,stage("selectors:load-failed",{error:String(a)}),a}}async function ensureSelectorsLoaded(e=""){SELECTORS||await loadSelectorsRemoteStrict(e)}const OVERLAY_ID="wz-overlay";async function ensureOverlay(e){}async function overlayLog(e,a,t="stage"){}async function removeOverlay(e){}const HUD_ID="pato-hud";async function hudShow(e,a=0){await chrome.scripting.executeScript({target:{tabId:e},func:(t,r)=>{if(document.getElementById(t))return;const n=typeof chrome<"u"&&chrome.runtime&&chrome.runtime.getURL?chrome.runtime.getURL("icons/duck-loading.gif"):"icons/duck-loading.gif",o=document.createElement("style");o.id=t+"-style",o.textContent=`
        #${t}{
          position:fixed; inset:0; z-index:2147483646;
          background:
            radial-gradient(circle at 10% 0%, rgba(34,197,235,.12), transparent 55%),
            radial-gradient(circle at 100% 100%, rgba(59,130,246,.16), #020617f0);
          backdrop-filter: blur(3px);
          display:flex; align-items:center; justify-content:center;
          pointer-events:none;
        }
        #${t} .hud-card{
          width:min(520px, 92vw);
          background: linear-gradient(145deg, rgba(15,23,42,.96), rgba(15,23,42,.92));
          color:#e5eefc;
          border-radius:20px;
          padding:22px 22px 16px;
          box-shadow:
            0 22px 70px rgba(0,0,0,.70),
            0 0 0 1px rgba(148,163,184,.22);
          display:flex; flex-direction:column; gap:12px;
          text-align:left;
          position:relative;
          overflow:hidden;
          pointer-events:auto;
          font-family: system-ui, -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", sans-serif;
        }
        #${t} .hud-card::before{
          content:'';
          position:absolute;
          inset:-40%;
          background:
            radial-gradient(circle at 0% 0%, rgba(56,189,248,.10), transparent 55%),
            radial-gradient(circle at 120% 50%, rgba(96,165,250,.10), transparent 55%);
          opacity:.9;
          pointer-events:none;
        }
        #${t} .hud-close{
          position:absolute;
          top:10px;
          right:12px;
          width:22px;
          height:22px;
          border-radius:999px;
          border:1px solid #fecaca;
          background:#b91c1c;
          color:#fef2f2;
          font-size:14px;
          cursor:pointer;
          display:none;
          align-items:center;
          justify-content:center;
          padding:0;
        }
        #${t} .hud-close:hover{
          background:#ef4444;
          border-color:#fee2e2;
        }
        #${t} .hud-inner{
          position:relative;
          z-index:1;
          display:flex;
          flex-direction:column;
          gap:14px;
        }
        #${t} .hud-header{
          display:flex; align-items:center; justify-content:space-between;
          gap:10px;
        }
        #${t} .hud-row-main{
          display:flex; align-items:center; gap:12px;
        }
        #${t} .hud-img{
          width:70px; height:70px;
          border-radius:16px;
          object-fit:contain;
          background: radial-gradient(circle at 30% 0%, rgba(56,189,248,.18), rgba(15,23,42,1));
          box-shadow:0 12px 30px rgba(15,23,42,.9);
          padding:6px;
        }
        #${t} .hud-title-block{
          display:flex;
          flex-direction:column;
          gap:4px;
        }
        #${t} .hud-title{
          font-size:18px;
          font-weight:700;
          letter-spacing:.02em;
        }
        #${t} .hud-chip{
          display:inline-flex;
          align-items:center;
          gap:6px;
          border-radius:999px;
          background:rgba(37,99,235,.14);
          border:1px solid rgba(96,165,250,.40);
          padding:3px 9px;
          font-size:11px;
          color:#bfdbfe;
        }
        #${t} .hud-chip-dot{
          width:8px; height:8px;
          border-radius:999px;
          background:#22c55e;
          box-shadow:0 0 0 4px rgba(34,197,94,.30);
        }
        #${t} .hud-sub{
          font-size:13px;
          color:#9fb2d9;
          min-height:18px;
          margin-top:2px;
          line-height:1.5;
        }
        #${t} .bar{
          height:11px;
          background:rgba(15,23,42,1);
          border-radius:999px;
          overflow:hidden;
          box-shadow:inset 0 0 0 1px rgba(30,64,175,.6);
          position:relative;
        }
        #${t} .fill{
          height:100%;
          width:0%;
          background:linear-gradient(90deg, #22c55e, #22d3ee, #3b82f6);
          background-size:200% 100%;
          animation: hud-fill-move 2.4s ease-in-out infinite;
          transition:width .35s ease-out;
        }
        #${t} .hud-metrics{
          display:flex;
          align-items:center;
          justify-content:space-between;
          font-size:11px;
          color:#a8bbdf;
          gap:10px;
        }
        #${t} .hud-count{
          min-height:16px;
        }
        #${t} .hud-pct{
          font-variant-numeric:tabular-nums;
          font-weight:600;
          color:#e5e7eb;
        }
        #${t} .hud-detail{
          font-size:12px;
          color:#cbd5f5;
          min-height:16px;
          line-height:1.5;
        }
        #${t} .hud-footer{
          margin-top:2px;
          font-size:10px;
          color:#64748b;
          display:flex;
          justify-content:space-between;
          gap:8px;
          align-items:center;
        }
        #${t} .hud-footer .hint{
          display:flex; align-items:center; gap:4px;
        }
        #${t} .hud-footer .dot{
          width:6px; height:6px; border-radius:999px;
          background:#fbbf24;
        }
        #${t} .hud-footer .brand{
          opacity:.85;
        }
        #${t} .hud-download-btn{
          margin-top:8px;
          padding:6px 12px;
          border-radius:999px;
          border:1px solid #bbf7d0;
          background:#15803d;
          color:#ecfdf5;
          font-size:11px;
          cursor:pointer;
          display:none;
          align-self:flex-start;
        }
        #${t} .hud-download-btn:hover{
          background:#16a34a;
          border-color:#bbf7d0;
        }

        @keyframes hud-fill-move{
          0%{ background-position:0% 50%; }
          50%{ background-position:100% 50%; }
          100%{ background-position:0% 50%; }
        }
      `,document.head.appendChild(o);const l=document.createElement("div");l.id=t;const u=document.createElement("div");u.className="hud-card",u.setAttribute("role","dialog"),u.setAttribute("aria-modal","true"),u.setAttribute("aria-live","polite");const i=document.createElement("button");i.id=t+"-close",i.className="hud-close",i.type="button",i.textContent="\xD7",i.onclick=()=>{try{const v=document.getElementById(t);v&&v.remove();const A=document.getElementById(t+"-style");A&&A.remove();const M=document.documentElement;M.hasAttribute("data-pato-hud-scroll")&&(M.style.overflow=M.getAttribute("data-pato-hud-scroll")||"",M.removeAttribute("data-pato-hud-scroll"))}catch{}};const p=document.createElement("div");p.className="hud-inner";const c=document.createElement("div");c.className="hud-header";const s=document.createElement("div");s.className="hud-row-main";const d=document.createElement("img");d.className="hud-img",d.src=n,d.alt="PatoGo trabalhando",d.onerror=()=>d.style.display="none";const h=document.createElement("div");h.className="hud-title-block";const f=document.createElement("div");f.className="hud-title",f.textContent="Deixe o PatoGo trabalhar\u2026";const m=document.createElement("div");m.id=t+"-sub",m.className="hud-sub",m.textContent="Preparando envio\u2026",h.appendChild(f),h.appendChild(m),s.appendChild(d),s.appendChild(h);const y=document.createElement("div");y.className="hud-chip",y.innerHTML='<span class="hud-chip-dot"></span><span>Modo autom\xE1tico ativo</span>',c.appendChild(s),c.appendChild(y);const g=document.createElement("div");g.className="bar";const b=document.createElement("div");b.id=t+"-fill",b.className="fill",g.appendChild(b);const x=document.createElement("div");x.className="hud-metrics";const k=document.createElement("div");k.id=t+"-count",k.className="hud-count",k.textContent="0 / "+r+" enviados";const _=document.createElement("div");_.id=t+"-pct",_.className="hud-pct",_.textContent="0% conclu\xEDdo",x.appendChild(k),x.appendChild(_);const w=document.createElement("div");w.id=t+"-detail",w.className="hud-detail";const E=document.createElement("button");E.id=t+"-btn",E.className="hud-download-btn",E.textContent="Baixar relat\xF3rio em Excel",E.onclick=()=>{try{chrome.runtime.sendMessage({type:"HUD_DOWNLOAD_REPORT"},v=>{if(chrome.runtime.lastError){console.warn("HUD_DOWNLOAD_REPORT error:",chrome.runtime.lastError);return}console.log("HUD_DOWNLOAD_REPORT resp:",v)})}catch(v){console.error("Erro ao enviar HUD_DOWNLOAD_REPORT:",v)}};const S=document.createElement("div");S.className="hud-footer";const P=document.createElement("div");P.className="hint",P.innerHTML='<span class="dot"></span><span>Evite usar mouse/teclado at\xE9 o fim do envio.</span>';const T=document.createElement("div");T.className="brand",T.textContent="PatoGo \xB7 WhatsApp Automation",S.appendChild(P),S.appendChild(T),p.appendChild(c),p.appendChild(g),p.appendChild(x),p.appendChild(w),p.appendChild(E),p.appendChild(S),u.appendChild(i),u.appendChild(p),l.appendChild(u),document.documentElement.appendChild(l);const C=document.documentElement;C.getAttribute("data-pato-hud-scroll")||(C.setAttribute("data-pato-hud-scroll",C.style.overflow||""),C.style.overflow="hidden")},args:[HUD_ID,a]})}async function hudUpdate(e,{sent:a=0,total:t=0,sub:r="",detail:n="",processed:o=0,finished:l=!1}={}){await chrome.scripting.executeScript({target:{tabId:e},func:(u,i,p,c,s,d,h)=>{const f=document.getElementById(u+"-fill"),m=document.getElementById(u+"-sub"),y=document.getElementById(u+"-count"),g=document.getElementById(u+"-detail"),b=document.getElementById(u+"-pct"),x=document.getElementById(u+"-btn"),k=document.getElementById(u+"-close"),_=Math.max(1,p);let w=typeof d=="number"?d:0;w<=0&&i>0&&(w=i),w<i&&(w=i);const E=Math.max(0,Math.min(100,Math.round(w/_*100)));f&&(f.style.width=E+"%"),m&&(m.textContent=c||(h?"Lote finalizado!":"")),y&&(y.textContent=i+" / "+p+" enviados"),g&&(g.textContent=s||""),b&&(b.textContent=E+"% conclu\xEDdo"),x&&(x.style.display=h?"inline-flex":"none"),k&&(k.style.display=h?"flex":"none")},args:[HUD_ID,a,t,r,n,o,l]})}async function hudHide(e){await chrome.scripting.executeScript({target:{tabId:e},func:a=>{const t=document.getElementById(a);t&&t.remove();const r=document.getElementById(a+"-style");r&&r.remove();const n=document.documentElement;n.hasAttribute("data-pato-hud-scroll")&&(n.style.overflow=n.getAttribute("data-pato-hud-scroll")||"",n.removeAttribute("data-pato-hud-scroll"))},args:[HUD_ID]})}async function ensureInteractionGuard(e,a=[]){await chrome.scripting.executeScript({target:{tabId:e},func:t=>{if(window.__pato_guard_init)return;window.__pato_guard_init=!0;const r={enabled:!1,permitPtrUntil:0,permitKeyUntil:0,composerSelectors:Array.isArray(t)?t.slice():[]},n=c=>{try{c.preventDefault(),c.stopImmediatePropagation(),c.stopPropagation()}catch{}return!1},o={capture:!0,passive:!1},l=()=>Date.now(),u=c=>{const s=r.composerSelectors||[];for(const d of s)try{const h=document.querySelector(d);if(h&&(c===h||h.contains(c)))return!0}catch{}return!1},i=c=>{r.enabled&&(l()<=r.permitPtrUntil||n(c))},p=c=>{r.enabled&&(l()<=r.permitKeyUntil&&u(c.target)||n(c))};["mousedown","mouseup","click","dblclick","contextmenu","wheel","touchstart","touchmove","touchend","pointerdown","pointerup"].forEach(c=>addEventListener(c,i,o)),["keydown","keypress","keyup"].forEach(c=>addEventListener(c,p,o)),window.__pato_guard_api={enable(){r.enabled=!0},disable(){r.enabled=!1,r.permitPtrUntil=0,r.permitKeyUntil=0},permitPointer(c){r.permitPtrUntil=l()+(c||150)},permitKeys(c,s){r.permitKeyUntil=l()+(c||1e3),Array.isArray(s)&&s.length&&(r.composerSelectors=s.slice())}}},args:[a]})}async function guardEnable(e){await chrome.scripting.executeScript({target:{tabId:e},func:()=>window.__pato_guard_api&&window.__pato_guard_api.enable()})}async function guardDisable(e){await chrome.scripting.executeScript({target:{tabId:e},func:()=>window.__pato_guard_api&&window.__pato_guard_api.disable()})}async function guardPermitPointer(e,a=220){await chrome.scripting.executeScript({target:{tabId:e},func:t=>window.__pato_guard_api&&window.__pato_guard_api.permitPointer(t),args:[a]})}async function guardPermitKeys(e,a=12e3,t=[]){await chrome.scripting.executeScript({target:{tabId:e},func:(r,n)=>window.__pato_guard_api&&window.__pato_guard_api.permitKeys(r,n),args:[a,t]})}async function ensureMaximizedAndActive(e){}async function withCDP(e,a){stage("cdp:attach"),await chrome.debugger.attach({tabId:e},"1.3");try{return await a((r,n={})=>chrome.debugger.sendCommand({tabId:e},r,n))}finally{stage("cdp:detach"),await chrome.debugger.detach({tabId:e}).catch(()=>{})}}async function waitTabComplete(e,a=45e3){return new Promise(t=>{let r=!1;const n=setTimeout(()=>{r||(r=!0,chrome.tabs.onUpdated.removeListener(o),t())},a),o=(l,u)=>{if(l===e&&u.status==="complete"){if(r)return;r=!0,clearTimeout(n),chrome.tabs.onUpdated.removeListener(o),t()}};chrome.tabs.onUpdated.addListener(o)})}async function getOrOpenWATab(e=!1){const[a]=await chrome.tabs.query({active:!0,currentWindow:!0});if(a&&a.url&&/^https:\/\/web\.whatsapp\.com\/?/.test(a.url))return e&&(await chrome.tabs.reload(a.id,{bypassCache:!1}),await waitTabComplete(a.id)),a;const[t]=await chrome.tabs.query({url:"https://web.whatsapp.com/*"});if(t)return e&&(await chrome.tabs.reload(t.id,{bypassCache:!1}),await waitTabComplete(t.id)),t;const r=await chrome.tabs.create({url:"https://web.whatsapp.com/"});return await waitTabComplete(r.id),r}async function humanTypeText(e,a,t,r,n,o){const l=()=>pickMs(t);let u=randInt(HUMAN.microBreakEvery[0],HUMAN.microBreakEvery[1]),i=0;for(let p=0;p<a.length;p++){const c=a[p];if(c===`
`)await e("Input.dispatchKeyEvent",{type:"keyDown",key:"Shift",modifiers:8}),await e("Input.dispatchKeyEvent",{type:"keyDown",key:"Enter",code:"Enter",windowsVirtualKeyCode:13,nativeVirtualKeyCode:13,modifiers:8}),await e("Input.dispatchKeyEvent",{type:"keyUp",key:"Enter",code:"Enter",windowsVirtualKeyCode:13,nativeVirtualKeyCode:13,modifiers:8}),await e("Input.dispatchKeyEvent",{type:"keyUp",key:"Shift",modifiers:0}),await sleep(l()),i++;else{try{await e("Input.dispatchKeyEvent",{type:"keyDown",text:c,key:c}),await e("Input.dispatchKeyEvent",{type:"keyUp",text:c,key:c})}catch{await e("Input.insertText",{text:c})}await sleep(l()),i++}isPunctOrSpace(c)&&await sleep(pickMs(r));const s=a[p+1]||"";/\w/.test(c)&&!/\w/.test(s)&&Math.random()<n&&await sleep(pickMs(o)),i>=u&&(await sleep(pickMs(HUMAN.microBreakMs)),i=0,u=randInt(HUMAN.microBreakEvery[0],HUMAN.microBreakEvery[1]))}}async function countdown(e,a="countdown"){if(!(!e||e<=0))for(let t=e;t>0;t--)stage(a,{tminus:t}),await sleep(1e3)}async function focusSearch(e){if(!SELECTORS)throw new Error("selectors-not-loaded");stage("focus:start");const[{result:a}]=await chrome.scripting.executeScript({target:{tabId:e},func:t=>{const n=(u=>{for(const i of u||[]){const p=document.querySelector(i);if(p)return p}return null})(t.searchBox);if(!n)return{ok:!1,why:"search-not-found"};n.focus();const o=getSelection(),l=document.createRange();return l.selectNodeContents(n),l.collapse(!1),o.removeAllRanges(),o.addRange(l),{ok:!0}},args:[SELECTORS]});return!a||!a.ok?(fail("focus:fail",{why:a&&a.why||"unknown"}),!1):(stage("focus:ok"),!0)}async function getTargetRect(e,a){if(!SELECTORS)throw new Error("selectors-not-loaded");stage("find:start",{visibleText:a});const[{result:t}]=await chrome.scripting.executeScript({target:{tabId:e},func:(r,n)=>{const o=s=>(s||"").trim().toLowerCase().normalize("NFD").replace(new RegExp("\\p{Diacritic}","gu"),""),l=o(r),u=s=>{const d=[];for(const h of s||[]){const f=document.querySelectorAll(h);f&&f.length&&f.forEach(m=>d.push(m))}return d},i=s=>{for(const d of n.rowTitle||[]){const h=s.querySelector(d);if(h)return h}return null},p=s=>{if(!s)return null;s.scrollIntoView({block:"center"});const d=s.getBoundingClientRect(),h=Math.max(document.documentElement.clientWidth,window.innerWidth||0),f=Math.max(document.documentElement.clientHeight,window.innerHeight||0),m=Math.min(Math.max(2,Math.floor(d.left+d.width*.5)),h-2),y=Math.min(Math.max(2,Math.floor(d.top+Math.min(30,d.height/2))),f-2),g=i(s),b=g&&g.getAttribute&&g.getAttribute("title")||g&&g.textContent||s.getAttribute("aria-label")||"";return{x:m,y,label:String(b).trim()}},c=u(n.row).filter(s=>s.offsetParent!==null);for(const s of c){const d=i(s);if(!d)continue;const h=(n.highlight||[]).join(",");if(!h)continue;const f=d.querySelectorAll(h);for(const m of f){const y=o(m.textContent);if(y&&(y===l||y.includes(l)||l.includes(y))){const g=p(s);if(g)return{ok:!0,...g}}}}for(const s of c){const d=i(s),h=d&&d.getAttribute&&d.getAttribute("title")||d&&d.textContent||"",f=o(h);if(f&&(f===l||f.includes(l))){const m=p(s);if(m)return{ok:!0,...m}}}return{ok:!1,why:"row-title-or-highlight-in-title-not-found"}},args:[a,SELECTORS]});return!t||!t.ok?(fail("find:fail",{why:t&&t.why||"unknown"}),{ok:!1,why:t&&t.why||"unknown"}):(stage("find:ok",{label:t.label,coords:{x:t.x,y:t.y}}),t)}async function focusComposer(e,a=HUMAN.focusComposerRetries,t=HUMAN.focusComposerRetryMs){if(!SELECTORS)throw new Error("selectors-not-loaded");stage("compose:focus:start",{retries:a,waitRange:t});for(let r=0;r<a;r++){const[{result:n}]=await chrome.scripting.executeScript({target:{tabId:e},func:o=>{const u=(c=>{for(const s of c||[]){const d=document.querySelector(s);if(d)return d}return null})(o.composer);if(!u)return{ok:!1,why:"composer-not-found"};u.focus();const i=getSelection(),p=document.createRange();return p.selectNodeContents(u),i.removeAllRanges(),i.addRange(p),document.execCommand("delete",!1,null),u.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"deleteContentBackward"})),{ok:!0}},args:[SELECTORS]});if(n&&n.ok)return stage("compose:focus:ok",{attempt:r+1}),!0;stage("compose:focus:retry",{attempt:r+1,why:n&&n.why||"unknown"}),await sleep(pickMs(t))}return fail("compose:focus:fail",{why:"composer-not-found-after-retries"}),!1}async function readOpenChatTitle(e,a=6,t=250){if(!SELECTORS)throw new Error("selectors-not-loaded");let r="";for(let n=0;n<a;n++){const[{result:o}]=await chrome.scripting.executeScript({target:{tabId:e},func:l=>{const u=c=>{for(const s of c||[]){const d=document.querySelector(s);if(d)return d}return null};let i="";const p=u(l.openTitle||[]);return p&&(i=p.getAttribute&&p.getAttribute("title")||p.textContent||""),{title:String(i||"").trim()}},args:[SELECTORS]});if(r=o&&o.title||"",r)return r;await sleep(t)}return r}async function sendToContact(e,a,t,r=""){await ensureSelectorsLoaded(r);const n=await getOrOpenWATab();await ensureOverlay(n.id),await overlayLog(n.id,"Iniciando: "+e),await ensureMaximizedAndActive(n);try{await ensureInteractionGuard(n.id,SELECTORS?.composer||[]),await guardEnable(n.id)}catch{}try{await withCDP(n.id,async o=>{if(HUMAN.preSearchCountdownSec>0&&await countdown(HUMAN.preSearchCountdownSec,"preSearch:t-"),!await focusSearch(n.id))throw new Error("search-not-found");const l=[...SELECTORS?.searchBox||[],...SELECTORS?.composer||[]],u=Math.min(45e3,Math.max(4e3,800+String(e||"").length*35));await guardPermitKeys(n.id,u,l);for(let d=0;d<HUMAN.backspaces;d++)await o("Input.dispatchKeyEvent",{type:"keyDown",key:"Backspace",windowsVirtualKeyCode:8,nativeVirtualKeyCode:8}),await o("Input.dispatchKeyEvent",{type:"keyUp",key:"Backspace",windowsVirtualKeyCode:8,nativeVirtualKeyCode:8}),d%6===0&&await sleep(randInt(4,14));await overlayLog(n.id,"Digitando termo de busca\u2026"),await humanTypeText(o,e,HUMAN.searchKeyDelayMs,HUMAN.searchPunctPauseMs,HUMAN.searchWordPauseProb,HUMAN.searchWordPauseMs),await sleep(pickMs(HUMAN.afterSearchWaitMs));const i=await getTargetRect(n.id,e);if(!i||!i.ok)throw new Error("not-found:"+(i&&i.why||"unknown"));await overlayLog(n.id,"Contato: "+i.label),await guardPermitPointer(n.id,350),await o("Input.dispatchMouseEvent",{type:"mouseMoved",x:i.x,y:i.y,buttons:0}),await sleep(randInt(40,90)),await guardPermitPointer(n.id,350),await o("Input.dispatchMouseEvent",{type:"mousePressed",x:i.x,y:i.y,button:"left",clickCount:1}),await sleep(randInt(30,70)),await guardPermitPointer(n.id,350),await o("Input.dispatchMouseEvent",{type:"mouseReleased",x:i.x,y:i.y,button:"left",clickCount:1}),await sleep(pickMs(HUMAN.afterClickWaitMs));const p=await readOpenChatTitle(n.id,10,220);await overlayLog(n.id,`T\xEDtulo aberto: "${p}" / Procurado: "${e}"`),p||await sleep(300);let c=p?isMatchTermVsTitle(e,p):!1,s=!1;if(c||(await overlayLog(n.id,"Match de t\xEDtulo falhou \u2014 conferindo composer antes de abortar\u2026"),s=await focusComposer(n.id)),!(c||s))throw await overlayLog(n.id,`Chat aberto n\xE3o confere. Procurado="${e}" | Aberto="${p}"`,"err"),new Error("open-chat-mismatch");if(a){if(!s&&!await focusComposer(n.id))throw new Error("composer-not-found");const d=Math.min(6e4,Math.max(8e3,a.length*35));await guardPermitKeys(n.id,d,SELECTORS?.composer||[]),await overlayLog(n.id,"Digitando mensagem\u2026"),await humanTypeText(o,a,HUMAN.msgKeyDelayMs,HUMAN.msgPunctPauseMs,HUMAN.msgWordPauseProb,HUMAN.msgWordPauseMs),t&&(await guardPermitKeys(n.id,1500,SELECTORS?.composer||[]),await overlayLog(n.id,"Enviando\u2026"),await o("Input.dispatchKeyEvent",{type:"keyDown",key:"Enter",code:"Enter",windowsVirtualKeyCode:13,nativeVirtualKeyCode:13}),await o("Input.dispatchKeyEvent",{type:"keyUp",key:"Enter",code:"Enter",windowsVirtualKeyCode:13,nativeVirtualKeyCode:13}))}})}catch(o){throw await overlayLog(n.id,"Erro: "+(o&&o.message?o.message:String(o)),"err"),o}finally{try{await guardDisable(n.id)}catch{}await removeOverlay(n.id)}}async function processBatch(){if(!currentBatch.isRunning)return;if(currentBatch.currentIndex++,currentBatch.currentIndex>=currentBatch.contacts.length){currentBatch.isRunning=!1;const a=currentBatch.contacts.filter(r=>r.status==="enviado").length,t=currentBatch.contacts.filter(r=>r.status==="erro").length;if(currentBatch.targetTabId){try{await guardDisable(currentBatch.targetTabId)}catch{}try{await hudUpdate(currentBatch.targetTabId,{sent:a,total:currentBatch.contacts.length,sub:"Lote conclu\xEDdo!",detail:"",processed:currentBatch.contacts.length,finished:!0})}catch{}}currentBatch.targetTabId=null,sendToPopup({type:"BATCH_COMPLETE",sentCount:a,errorCount:t}),sendToPopup({type:"LOG_MESSAGE",level:"ok",text:"\u2705 LOTE CONCLU\xCDDO! "+a+" enviados, "+t+" erros"});return}const e=currentBatch.contacts[currentBatch.currentIndex];if(!e){if(currentBatch.isRunning){const a=pickMs(HUMAN.batchDelayMs);setTimeout(processBatch,a)}return}try{const a=currentBatch.targetTabId;if(a){const t=currentBatch.contacts.filter(o=>o.status==="enviado").length,r=currentBatch.contacts.filter(o=>o.status==="erro").length,n=t+r;await hudUpdate(a,{sent:t,total:currentBatch.contacts.length,sub:"Processando "+(currentBatch.currentIndex+1)+" / "+currentBatch.contacts.length,detail:"Enviando para: "+e.nome,processed:n})}}catch{}sendToPopup({type:"CONTACT_UPDATE",contactIndex:currentBatch.currentIndex,status:"enviando"}),sendToPopup({type:"BATCH_STATUS",active:!0,statusText:"Processando "+(currentBatch.currentIndex+1)+"/"+currentBatch.contacts.length+": "+e.nome});try{let a="";if(Array.isArray(currentBatch.messageTemplates)&&currentBatch.messageTemplates.length>0){const r=currentBatch.currentIndex%currentBatch.messageTemplates.length;a=currentBatch.messageTemplates[r]||""}else a=currentBatch.message||"";const t=personalizeMessage(a,e);await sendToContact(e.nome,t,currentBatch.sendAfter,currentBatch.email),e.status="enviado",sendToPopup({type:"CONTACT_UPDATE",contactIndex:currentBatch.currentIndex,status:"enviado"})}catch(a){e.status="erro",sendToPopup({type:"CONTACT_UPDATE",contactIndex:currentBatch.currentIndex,status:"erro"}),sendToPopup({type:"LOG_MESSAGE",level:"err",text:"Erro no contato "+e.nome+": "+(a&&a.message?a.message:String(a))})}try{const a=currentBatch.targetTabId;if(a){const t=currentBatch.contacts.filter(o=>o.status==="enviado").length,r=currentBatch.contacts.filter(o=>o.status==="erro").length,n=t+r;await hudUpdate(a,{sent:t,total:currentBatch.contacts.length,sub:"Progresso: "+n+" / "+currentBatch.contacts.length,detail:"",processed:n})}}catch{}if(currentBatch.isRunning){const a=pickMs(HUMAN.batchDelayMs);setTimeout(processBatch,a)}}chrome.runtime.onConnect.addListener(e=>{e.name==="batch-connection"&&(currentBatch.batchPort=e,e.onMessage.addListener(a=>{if(!(!a||!a.type)){if(a.type==="START_BATCH"){(async()=>{try{const t=safeEmail(a.email||"");try{await ensureSelectorsLoaded(t)}catch(o){console.error("Falha ao carregar selectors:",o),sendToPopup({type:"LOG_MESSAGE",level:"err",text:"Falha ao carregar seletores. Tente novamente."}),currentBatch.isRunning=!1,currentBatch.targetTabId=null;return}const r=isProFromServerMeta(SEND_BUNDLE_META);if(!r){const o=await gateConsumeOrBlock(t);if(o.blocked){sendGateBlockedToPopup(o.data),sendToPopup({type:"BATCH_STATUS",active:!1,statusText:"Limite FREE atingido. Aguarde o contador."}),sendToPopup({type:"LOG_MESSAGE",level:"warn",text:"Limite FREE atingido. Aguarde o tempo do contador."}),currentBatch.isRunning=!1,currentBatch.targetTabId=null;return}}const n=Array.isArray(a.messages)?a.messages.filter(o=>typeof o=="string").map(o=>o.trim()).filter(o=>o.length>0):[];if(currentBatch={isRunning:!0,contacts:Array.isArray(a.contacts)?a.contacts.map(o=>({...o,status:o.status||"pendente"})):[],message:a.message||"",messageTemplates:n.length?n:null,sendAfter:!!a.sendAfter,currentIndex:-1,batchPort:e,targetTabId:null,email:t,isPro:r},!currentBatch.contacts.length){sendToPopup({type:"LOG_MESSAGE",level:"err",text:"Nenhum contato para enviar."}),currentBatch.isRunning=!1;return}try{const o=await getOrOpenWATab(!0);await sleep(1e4),currentBatch.targetTabId=o.id,await hudShow(o.id,currentBatch.contacts.length),await hudUpdate(o.id,{sent:0,total:currentBatch.contacts.length,sub:"Iniciando\u2026",detail:"",processed:0})}catch(o){console.error("Erro ao preparar WhatsApp/HUD:",o),sendToPopup({type:"LOG_MESSAGE",level:"err",text:"N\xE3o foi poss\xEDvel preparar o WhatsApp para envio. Tente novamente."}),currentBatch.isRunning=!1,currentBatch.targetTabId=null;return}processBatch()}catch(t){console.error("START_BATCH fatal:",t),sendToPopup({type:"LOG_MESSAGE",level:"err",text:"Falha ao validar limite/seletores no servidor."}),currentBatch.isRunning=!1,currentBatch.targetTabId=null}})();return}if(a.type==="STOP_BATCH"){(async()=>{if(currentBatch.isRunning=!1,sendToPopup({type:"BATCH_STATUS",active:!1,statusText:"Lote parado"}),sendToPopup({type:"LOG_MESSAGE",level:"warn",text:"\u23F9\uFE0F LOTE PARADO PELO USU\xC1RIO"}),currentBatch.targetTabId)try{const t=currentBatch.contacts.filter(r=>r.status==="enviado").length;await guardDisable(currentBatch.targetTabId),await hudUpdate(currentBatch.targetTabId,{sent:t,total:currentBatch.contacts.length,sub:"Envio interrompido.",detail:"",processed:currentBatch.currentIndex+1}),await hudHide(currentBatch.targetTabId)}catch{}currentBatch.targetTabId=null})();return}}}),e.onDisconnect.addListener(()=>{currentBatch.batchPort=null}))}),chrome.runtime.onMessage.addListener((e,a,t)=>{if(!(!e||!e.type)){if(e.type==="SINGLE_MESSAGE")return(async()=>{try{const r=e.contact&&e.contact.nome||e.nome||e.name||e.term||"",n={nome:r},o=String(e.message||""),l=personalizeMessage(o,n);await sendToContact(r,l,!!e.sendAfter,safeEmail(e.email||"")),t&&t({ok:!0})}catch(r){fail("single:error",{error:String(r)}),t&&t({ok:!1,error:String(r)})}})(),!0;if(e.type==="RELOAD_REMOTE_SELECTORS")return loadSelectorsRemoteStrict(safeEmail(e.email||"")).then(()=>t&&t({ok:!0})).catch(r=>t&&t({ok:!1,error:String(r)})),!0;if(e.type==="HUD_DOWNLOAD_REPORT")return(async()=>{try{const r=currentBatch&&Array.isArray(currentBatch.contacts)?currentBatch.contacts:[];if(!r.length){t&&t({ok:!1,error:"Nenhum contato no lote atual."});return}const n=["#","Nome","Status"],o=r.map((c,s)=>[s+1,c.nome||"",c.status||""]),l=c=>{const s=String(c??"");return/[;"\n\r]/.test(s)?`"${s.replace(/"/g,'""')}"`:s},i=[n.map(l).join(";"),...o.map(c=>c.map(l).join(";"))].join(`\r
`),p="data:text/csv;charset=utf-8,"+encodeURIComponent("\uFEFF"+i);chrome.downloads.download({url:p,filename:"patogo_relatorio_envio.csv",saveAs:!0},()=>{const c=chrome.runtime.lastError;if(c){console.error("Erro no chrome.downloads.download:",c),t&&t({ok:!1,error:String(c)});return}t&&t({ok:!0})})}catch(r){console.error("Erro em HUD_DOWNLOAD_REPORT:",r),t&&t({ok:!1,error:String(r)})}})(),!0;if(e.type==="GET_HUMAN_CONFIG")return(async()=>{try{await loadHumanConfig(),t&&t({ok:!0,human:HUMAN,defaults:DEFAULT_HUMAN})}catch(r){t&&t({ok:!1,error:String(r)})}})(),!0;if(e.type==="SET_HUMAN_CONFIG")return(async()=>{try{if(e.human==="DEFAULT"){await chrome.storage.sync.remove("humanConfig"),HUMAN=JSON.parse(JSON.stringify(DEFAULT_HUMAN)),t&&t({ok:!0,human:HUMAN,reset:!0});return}const r=e.human||{},n=normalizeHumanConfig(r);HUMAN=n,await chrome.storage.sync.set({humanConfig:n}),t&&t({ok:!0,human:n,reset:!1})}catch(r){console.error("Erro em SET_HUMAN_CONFIG:",r),t&&t({ok:!1,error:String(r)})}})(),!0;if(e.type==="SEND_GATE_PEEK")return(async()=>{try{const r=safeEmail(e.email||""),n=await fetchSendBundle({email:r,peek:!0});if(isBlockedMeta(n)){t&&t({ok:!0,blocked:!0,until_epoch:extractUntilEpoch(n.data),until_brt:n.data?.cooldown?.until_brt||""});return}t&&t({ok:!0,blocked:!1})}catch(r){t&&t({ok:!1,error:String(r)})}})(),!0}}),chrome.runtime.onInstalled.addListener(()=>{console.log("PatoGo \u2014 background pronto (estrito, sem default)."),loadSelectorsRemoteStrict().catch(()=>{}),loadHumanConfig().catch(()=>{})});
